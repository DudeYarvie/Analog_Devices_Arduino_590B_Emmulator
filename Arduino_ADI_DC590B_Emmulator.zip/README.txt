This code is the complete package to emmulate the DC590 on an Arduino UNO.  

It should be noted that the UNO does not possess the buffers on the SPI lines like the DC590 or Linduino.  
These buffes allow the HW to adjust the voltage level of the bus. The Arduino implement +5V logic.